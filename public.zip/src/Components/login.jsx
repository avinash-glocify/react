import React from 'react';

class User extends React.Component {
  onSubmit = () => {
    this.props.history.push('/')
  }
  render() {
    return <div className="container">
      <div className="row">
        <div className="col-md-6 offset-3 mt-5">
          <div className="card">
            <div className="card-body">
              <form>
                <div className="form-group">
                  <label>Email address:</label>
                  <input type="email" className="form-control" placeholder="Enter email" id="email" />
                </div>
                <div className="form-group">
                  <label>Password:</label>
                  <input type="password" className="form-control" placeholder="Enter password" id="pwd" />
                </div>
                <div className="form-group form-check">
                  <label className="form-check-label">
                    <input className="form-check-input" type="checkbox" /> Remember me
                  </label>
                </div>
                <button type="button" onClick={this.onSubmit} className="btn btn-primary">Submit</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>;
  }
};
export default User;
