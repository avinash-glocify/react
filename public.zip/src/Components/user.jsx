import React  from 'react';

class User extends React.Component {
  constructor(props) {
    super(props);
    this.state = { 'user' : [], 'isLoading': true };
  }
  componentDidMount() {
    const userId = this.props.match.params.id
    fetch(`https://jsonplaceholder.typicode.com/users/${userId}`)
      .then(res => res.json())
      .then(
        (result) => {
          this.setState({
            user: result,
            isLoading: false,
          });
        },
        (error) => {
          this.setState({
            isLoading: false,
            error
          });
        }
      )
  }
  render() {
    if(this.state.isLoading) {
    return <div className="container">
              <div className="d-flex justify-content-center mt-5">
                <div className="spinner-border" role="status">
                  <span className="sr-only">Loading...</span>
                </div>
              </div>
            </div>;
    } else {
      return <div className="container">
      <h2 className="bg-success p-1">User Name: {this.state.user.username}</h2>
      <table className="table table-dark table-striped mt-5">
        <thead>
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>Username</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Website</th>
          </tr>
        </thead>
      <tbody>
        <tr key={this.state.user.id}>
          <td>{this.state.user.id}</td>
          <td>{this.state.user.name}</td>
          <td>{this.state.user.username}</td>
          <td>{this.state.user.email}</td>
          <td>{this.state.user.phone}</td>
          <td>{this.state.user.website}</td>
        </tr>
      </tbody>
      </table>
      </div>;
    }
  }
};
export default User;
