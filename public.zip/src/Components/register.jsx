import React from 'react';

class Register extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
        email : '',
        first_name : '',
        last_name : '',
        password : '',
    };
  }
  onSubmit = (event) => {
    console.log(this.state);
    // this.props.history.push('/')
    fetch('http://gis.co/api/auth/register', {
       method: 'post',
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET,PUT,POST,DELETE,PATCH,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With",
      }
     })
    .then(response => response.json())
    .then(result => {
      console.log(result);
    }).catch(error => { console.log(error) })
  }
  onChange = e => {
    this.setState({[e.target.name]: e.target.value
    })
    console.log(this.state);
  }
  render() {
    return <div className="container">
      <div className="row">
        <div className="col-md-6 offset-3 mt-5">
          <div className="card">
            <div className="card-header">
              Register
            </div>
            <div className="card-body">
              <form>
                <div className="form-group">
                  <label>Firs Name:</label>
                  <input type="text" name="first_name"  className="form-control"  placeholder="Enter First Name" id="first_name" onChange={this.onChange} value={this.state.first_name === null ? '' : this.state.first_name}/>
                </div>
                <div className="form-group">
                  <label>Last Name</label>
                  <input type="text" className="form-control" name="last_name" placeholder="Enter Last Name" onChange={this.onChange} value={this.state.last_name === null ? '' :this.state.last_name} id="last_name" />
                </div>
                <div className="form-group">
                  <label>Email address:</label>
                  <input type="email" className="form-control" placeholder="Enter email" name="email" id="email" onChange={this.onChange} value={this.state.email === null ? '' : this.state.email} />
                </div>
                <div className="form-group">
                  <label>Password:</label>
                  <input type="password" className="form-control" placeholder="Enter password" name="password" id="pwd" onChange={this.onChange} value={this.state.password === null ? '' : this.state.password} />
                </div>
                <button type="button" onClick={this.onSubmit} className="btn btn-primary">Submit</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>;
  }
};
export default Register;
