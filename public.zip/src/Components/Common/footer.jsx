import React from 'react';

const template = <footer className="container-fluid bg-4 text-center mt-5">
    <p>Bootstrap Theme Made By <a href="https://www.w3schools.com">Avinash Negi</a></p>
  </footer>;

class Footer extends React.Component {
  render() {
    return template;
  }
};
export default Footer;
