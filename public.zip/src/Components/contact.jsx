import React  from 'react';

const template = <h2>Contact Component</h2>;

class Contact extends React.Component {
  render() {
    return template;
  }
};
export default Contact;
